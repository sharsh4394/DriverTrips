import { Component } from '@angular/core';
import{ Filetoupload } from './Shared/filetoupload';
import { FileUploadService } from './Shared/file-upload.service';
const MAX_SIZE: number = 1048576;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'InputFileUpload';
  theFile: any = null;
  messages: string[] = [];

  
constructor(private uploadService: FileUploadService) {

 }

 onFileChange(event) {
  this.theFile = null;
  if (event.target.files && event.target.files.length > 0) {
      // Don't allow file sizes over 1MB
      if (event.target.files[0].size < MAX_SIZE) {
          // Set theFile property
          this.theFile = event.target.files[0];
      }
      else {
          // Display error message
          this.messages.push("File: " + event.target.files[0].name + " is too large to upload.");
      }
  }

}

private readAndUploadFile(theFile: any) {
  let file = new Filetoupload();
  
  file.fileSize = theFile.size;
  let reader = new FileReader();
  
  // Setup onload event for reader
  reader.onload = () => {
      // Store base64 encoded representation of file
      file.fileAsBase64 = reader.result.toString();
      
      // POST to server
      this.uploadService.uploadFile(file).subscribe(resp => { 
          this.messages = resp; });
  }
  
  // Read the file
  reader.readAsDataURL(theFile);
}

uploadFile(): void {
  this.readAndUploadFile(this.theFile);
}


}
