export class Filetoupload {
    fileSize: number = 0;
    fileAsBase64: string = "";
}
