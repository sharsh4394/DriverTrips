import { Filetoupload } from './filetoupload';

describe('Filetoupload', () => {
  it('should create an instance', () => {
    expect(new Filetoupload()).toBeTruthy();
  });
});
