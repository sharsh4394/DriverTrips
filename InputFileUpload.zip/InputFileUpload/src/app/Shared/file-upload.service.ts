import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Filetoupload } from './filetoupload';
const API_URL = "http://localhost:59136/api/DriverReports/";
const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
};
@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  constructor(private http: HttpClient) {
   
   }

   uploadFile(theFile: Filetoupload) : Observable<any> {
    return this.http.post<Filetoupload>(API_URL, theFile, httpOptions);
}

}
